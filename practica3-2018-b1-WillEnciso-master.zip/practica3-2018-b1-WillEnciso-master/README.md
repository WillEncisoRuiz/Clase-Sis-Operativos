# Practice 3

Repository with the files of the practice 3 for the course 2017/2018.

## Students that will participate in the practice

Student 1: Wilfredo Julián Enciso Ruiz
Student 2 (optional):
