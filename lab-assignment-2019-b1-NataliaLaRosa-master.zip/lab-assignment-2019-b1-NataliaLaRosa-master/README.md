# Laboratory assigment

Repository with the files of the laboratory assignment for the course 2018-2019

## Students that will participate in the practice

Student 1: Natalia P. La Rosa Montero

Student 2 (optional): Wilfredo J. Enciso Ruiz
